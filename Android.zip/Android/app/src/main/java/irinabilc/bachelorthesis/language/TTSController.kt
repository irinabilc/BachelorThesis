package irinabilc.bachelorthesis.language

import android.content.Context
import android.speech.tts.TextToSpeech

class TTSController{
    private var tts: TextToSpeech? = null
    fun initialize(context: Context){
        val listener = TTSListener()
        tts = TextToSpeech(context, listener)
    }

    fun speakOut(message: String){

    }
}